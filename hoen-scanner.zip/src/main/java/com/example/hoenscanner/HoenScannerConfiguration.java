
package com.example.hoenscanner;

import io.dropwizard.Configuration;

public class HoenScannerConfiguration extends Configuration {
}
