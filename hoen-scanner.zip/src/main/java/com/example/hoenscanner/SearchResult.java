
package com.example.hoenscanner;

import com.fasterxml.jackson.annotation.JsonProperty;

public class SearchResult {
    @JsonProperty
    public String city;

    @JsonProperty
    public String kind;

    @JsonProperty
    public String title;

    public SearchResult() {}

    public SearchResult(String city, String kind, String title) {
        this.city = city;
        this.kind = kind;
        this.title = title;
    }
}
