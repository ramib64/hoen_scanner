
package com.example.hoenscanner;

import io.dropwizard.Application;
import io.dropwizard.setup.Bootstrap;
import io.dropwizard.setup.Environment;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class HoenScannerApplication extends Application<HoenScannerConfiguration> {
    public static void main(String[] args) throws Exception {
        new HoenScannerApplication().run(args);
    }

    @Override
    public void initialize(Bootstrap<HoenScannerConfiguration> bootstrap) {
    }

    @Override
    public void run(HoenScannerConfiguration configuration, Environment environment) throws Exception {
        ObjectMapper mapper = new ObjectMapper();
        List<SearchResult> searchResults = new ArrayList<>();

        searchResults.addAll(Arrays.asList(
                mapper.readValue(new File("src/main/resources/rental_cars.json"), SearchResult[].class)
        ));
        searchResults.addAll(Arrays.asList(
                mapper.readValue(new File("src/main/resources/hotels.json"), SearchResult[].class)
        ));

        environment.jersey().register(new SearchResource(searchResults));
        System.out.println("Welcome to Hoen Scanner!");
    }
}
